<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserFactory extends Factory
{
    protected static ?string $password;
    public function definition(): array
    {
        return [
            'public_id' => Str::uuid(), 'name' => fake()->name(), 'email' => fake()->unique()->safeEmail(),
            'email_verified_at' => now(), 'password' => static::$password ??= Hash::make('password'),
            'remember_token' => Str::random(10), 'is_active' => true,
        ];
    }
    public function unverified(): static { return $this->state(fn () => ['email_verified_at' => null]); }
    public function superAdmin(): static { return $this->state(fn () => ['is_super_admin' => true]); }
}
